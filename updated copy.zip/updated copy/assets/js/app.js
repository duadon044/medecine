// assets/js/app.js - MediPOS client app (simplified, self-contained)
// Note: This file is intended for development/demo purposes. Replace with production-grade code for real deployments.

// --- CONFIG ---
const API_BASE = 'http://localhost:4000/api';
let authToken = null;

// --- STATE ---
let medicines = [];
let users = [];
let pendingUsers = [];
let leaveRequests = [];
let receipts = [];
let archives = [];
let activities = [];
let cart = [];
let heldCarts = [];
let discount = 0;
let nextOrderId = 1001;
let currentUser = null;

// --- DEFAULT DATA ---
function getDefaultMedicines() {
    return [
        { id: 1, name: 'Paracetamol 500mg', category: 'Pain Relief', price: 8.5, stock: 120, expiryDate: '2026-12-31', status: 'active' },
        { id: 2, name: 'Ibuprofen 400mg', category: 'Pain Relief', price: 12.0, stock: 85, expiryDate: '2026-10-15', status: 'active' },
        { id: 3, name: 'Amoxicillin 500mg', category: 'Antibiotic', price: 25.0, stock: 45, expiryDate: '2026-09-20', status: 'active' }
    ];
}
function getDefaultUsers() { return [ { id:1, username:'admin', fullname:'System Administrator', password:'Admin@123', role:'Admin', status:'active' } ]; }
function getDefaultPendingUsers(){ return []; }
function getDefaultLeaveRequests(){ return []; }

// --- API HELPERS ---
async function apiFetch(path, options = {}){
    const url = `${API_BASE}${path}`;
    const opts = Object.assign({ headers: { 'Content-Type': 'application/json' } }, options);
    if (authToken) opts.headers.Authorization = `Bearer ${authToken}`;
    if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    const res = await fetch(url, opts).catch(e=>{ throw new Error('Network error'); });
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('application/json') ? await res.json() : await res.text();
    if (!res.ok) throw new Error((data && data.message) ? data.message : res.statusText);
    return data;
}

// --- STORAGE ---
function saveToStorage(){
    localStorage.setItem('medipos_medicines', JSON.stringify(medicines));
    localStorage.setItem('medipos_users', JSON.stringify(users));
    localStorage.setItem('medipos_pendingUsers', JSON.stringify(pendingUsers));
    localStorage.setItem('medipos_receipts', JSON.stringify(receipts));
    localStorage.setItem('medipos_archives', JSON.stringify(archives));
    localStorage.setItem('medipos_activities', JSON.stringify(activities));
    localStorage.setItem('medipos_nextOrderId', String(nextOrderId));
}

async function loadFromStorage(){
    medicines = JSON.parse(localStorage.getItem('medipos_medicines')||'null') || getDefaultMedicines();
    users = JSON.parse(localStorage.getItem('medipos_users')||'null') || getDefaultUsers();
    pendingUsers = JSON.parse(localStorage.getItem('medipos_pendingUsers')||'null') || getDefaultPendingUsers();
    receipts = JSON.parse(localStorage.getItem('medipos_receipts')||'null') || [];
    archives = JSON.parse(localStorage.getItem('medipos_archives')||'null') || [];
    activities = JSON.parse(localStorage.getItem('medipos_activities')||'null') || [];
    const no = localStorage.getItem('medipos_nextOrderId'); if (no) nextOrderId = parseInt(no,10);
    // try to sync authoritative data if token present
    if (authToken){
        try{
            const prods = await apiFetch('/products'); if (Array.isArray(prods)) medicines = prods.map(p=>({ id:p.id, name:p.name, category:p.category, price:parseFloat(p.price), stock:parseInt(p.stock), expiryDate:p.expiry_date||null, status:p.status }));
            const recs = await apiFetch('/receipts'); if (Array.isArray(recs)) receipts = recs.map(r=>({ orderId:r.order_id||r.id, date:r.date, items:r.items||[], subtotal:r.subtotal||0, discount:r.discount||0, total:r.total||0, cashier:r.cashier||'' }));
            const us = await apiFetch('/admin/users').catch(()=>null); if (Array.isArray(us)) users = us;
        }catch(e){ console.warn('Sync failed',e.message); }
    }
}

// --- UTIL ---
function showToast(msg, type='info'){ const t=document.getElementById('toast'); if(!t) return; t.textContent=msg; t.className=`toast ${type}`; clearTimeout(t._to); void t.offsetWidth; t.classList.add('show'); t._to=setTimeout(()=>t.classList.remove('show'),3000); }
function addActivity(msg){ activities.unshift({ message:msg, time:new Date().toISOString() }); if (activities.length>200) activities.length=200; saveToStorage(); }

// --- AUTH ---
async function handleLogin(e){ e&&e.preventDefault(); const user=document.getElementById('loginUsername').value.trim(); const pass=document.getElementById('loginPassword').value; if(!user||!pass){ showToast('Fill fields','error'); return; }
    try{ const data = await apiFetch('/auth/login',{ method:'POST', body:{ username:user, password:pass } }); authToken=data.token; currentUser=data.user; document.getElementById('loginPage').style.display='none'; document.getElementById('mainApp').style.display='block'; await loadFromStorage(); renderMainApp(); initApp(); showToast('Logged in','success'); addActivity(`Login (server): ${currentUser.username}`); return; }catch(e){ console.warn('server login failed',e.message); }
    // local fallback
    const u = users.find(x=>x.username===user && x.password===pass); if(!u){ showToast('Invalid credentials','error'); return; } currentUser=u; document.getElementById('loginPage').style.display='none'; document.getElementById('mainApp').style.display='block'; await loadFromStorage(); renderMainApp(); initApp(); showToast('Logged in (local)','success'); addActivity(`Login (local): ${currentUser.username}`);
}
function logout(){ authToken=null; currentUser=null; document.getElementById('mainApp').innerHTML=''; document.getElementById('loginPage').style.display='flex'; showToast('Logged out','info'); }

// --- UI RENDER ---
function renderMainApp(){
    const app = document.getElementById('mainApp');
    app.innerHTML = `
    <header class="header">
        <div><h1>💊 <span>Medi</span>POS</h1><div class="date-time" id="dateTime"></div></div>
        <div class="user-info"><span id="currentUserDisplay">${currentUser?currentUser.fullname:'Guest'}</span><div class="avatar" id="userAvatar">${currentUser?currentUser.fullname.charAt(0):'G'}</div><button class="logout-btn" onclick="logout()">Logout</button></div>
    </header>
    <nav class="nav-tabs" id="navTabs">
        <button class="active" data-tab="dashboard">Dashboard</button>
        <button data-tab="pos">Point of Sale</button>
        <button data-tab="products">Products</button>
        <button data-tab="users">Users</button>
        <button data-tab="receipts">Receipts</button>
        <button data-tab="archives">Archives</button>
        <button data-tab="hr">HR</button>
    </nav>
    <div class="container">
        <div class="tab-content active" id="tab-dashboard"><h3>Dashboard</h3><div id="dashboardArea"></div></div>
        <div class="tab-content" id="tab-pos"><div class="search-bar"><input id="searchInput" placeholder="Search..." oninput="renderProducts()"></div><div id="productGrid" class="product-grid"></div><div id="cartArea"></div></div>
        <div class="tab-content" id="tab-products"><h3>Product Management</h3><button onclick="showAddProductModal()">Add</button><div id="productTable"></div></div>
        <div class="tab-content" id="tab-users"><h3>Users</h3><div id="pendingUsersSection"></div><div id="userTable"></div></div>
        <div class="tab-content" id="tab-receipts"><h3>Receipts</h3><div id="receiptTable"></div></div>
        <div class="tab-content" id="tab-archives"><h3>Archives</h3><div id="archiveTable"></div></div>
        <div class="tab-content" id="tab-hr"><h3>HR</h3><div id="leaveTable"></div></div>
    </div>

    <!-- Modals containers -->
    <div id="modals"></div>
    `;
}

function initApp(){ document.getElementById('currentUserDisplay').textContent = `👤 ${currentUser.fullname}`; document.getElementById('userAvatar').textContent = currentUser.fullname.charAt(0).toUpperCase(); setupNavigation(); renderAll(); setInterval(()=>document.getElementById('dateTime').textContent = new Date().toLocaleString(),1000); }

function setupNavigation(){ document.querySelectorAll('.nav-tabs button').forEach(btn=>btn.onclick=function(){ document.querySelectorAll('.nav-tabs button').forEach(b=>b.classList.remove('active')); this.classList.add('active'); const tab=this.dataset.tab; document.querySelectorAll('.tab-content').forEach(tc=>tc.classList.remove('active')); document.getElementById('tab-'+tab).classList.add('active'); renderAll(); }); }

function renderAll(){ updateDashboard(); renderProducts(); renderProductTable(); renderUserTable(); renderPendingUsers(); renderReceiptTable(); renderArchives(); renderLeaveRequests(); updateCartUI(); }

// --- DASHBOARD ---
function updateDashboard(){ const el=document.getElementById('dashboardArea'); if(!el) return; const total=receipts.reduce((s,r)=>s+(r.total||0),0); el.innerHTML=`<div class="dashboard-stats">Total revenue: ₱${total.toFixed(2)}</div>`; }

// --- PRODUCTS / POS ---
function renderProducts(){ const grid=document.getElementById('productGrid'); if(!grid) return; const q=document.getElementById('searchInput')?.value?.toLowerCase()||''; const items=medicines.filter(m=>m.status==='active' && m.name.toLowerCase().includes(q)); if(items.length===0){ grid.innerHTML='<div style="padding:20px;color:#999">No products</div>'; return; } grid.innerHTML=items.map(m=>`<div class="product-card" onclick="addToCart(${m.id})"><div class="name">${m.name}</div><div class="price">₱${m.price.toFixed(2)}</div><div class="stock">Stock: ${m.stock}</div></div>`).join(''); }

function addToCart(id){ const p=medicines.find(x=>x.id===id); if(!p) return; if(p.stock<=0){ showToast('Out of stock','error'); return; } const ex=cart.find(i=>i.id===id); if(ex){ if(ex.qty<p.stock) ex.qty++; else { showToast('Not enough stock','warning'); return; } } else cart.push({ id:p.id, name:p.name, price:p.price, qty:1 }); updateCartUI(); showToast('Added to cart','success'); }

function updateCartUI(){ const area=document.getElementById('cartArea'); if(!area) return; if(cart.length===0){ area.innerHTML='<div class="empty-cart">Cart is empty</div>'; return; } const rows=cart.map(i=>`<div class="cart-item"><div>${i.name} x ${i.qty}</div><div>₱${(i.price*i.qty).toFixed(2)}</div><div><button onclick="decItem(${i.id})">-</button><button onclick="incItem(${i.id})">+</button><button onclick="removeItem(${i.id})">x</button></div></div>`).join(''); const subtotal=cart.reduce((s,i)=>s+i.price*i.qty,0); area.innerHTML=`<div>${rows}</div><div class="cart-summary">Subtotal: ₱${subtotal.toFixed(2)}</div><div><button onclick="checkout()">Checkout</button><button onclick="clearCart()">Clear</button></div>`; }
function incItem(id){ const it=cart.find(i=>i.id===id); const p=medicines.find(m=>m.id===id); if(it && p && it.qty<p.stock){ it.qty++; updateCartUI(); } }
function decItem(id){ const it=cart.find(i=>i.id===id); if(it){ it.qty--; if(it.qty<=0) cart=cart.filter(x=>x.id!==id); updateCartUI(); } }
function removeItem(id){ cart=cart.filter(x=>x.id!==id); updateCartUI(); }
function clearCart(){ if(confirm('Clear cart?')){ cart=[]; updateCartUI(); showToast('Cart cleared','info'); } }

async function checkout(){ if(cart.length===0){ showToast('Cart empty','error'); return; } const subtotal=cart.reduce((s,i)=>s+i.price*i.qty,0); const discountAmount=(subtotal*discount)/100; const total=subtotal-discountAmount;
    if (authToken){ try{ const payload={ items: cart.map(i=>({ product_id:i.id, qty:i.qty })), discount }; const data=await apiFetch('/receipts',{ method:'POST', body:payload }); // server returns receipt
            const rec=data.receipt||data; receipts.unshift({ orderId:rec.order_id||rec.id, date:rec.date||new Date().toISOString(), items:cart.slice(), subtotal, discount, discountAmount, total, cashier: currentUser.fullname }); saveToStorage(); cart=[]; updateCartUI(); renderProductTable(); renderReceiptTable(); showToast('Checkout successful (server)','success'); addActivity(`Sale ${receipts[0].orderId} (server)`); return; }catch(e){ console.warn('server checkout failed',e.message); showToast('Server checkout failed, using local mode','warning'); }
    }
    // local fallback
    const receipt = { orderId: nextOrderId++, date: new Date().toISOString(), items: cart.slice(), subtotal, discount, discountAmount, total, cashier: currentUser.fullname }; receipts.unshift(receipt); cart=[]; medicines.forEach(m=>{ const it=receipt.items.find(i=>i.id===m.id); if(it) m.stock-=it.qty; }); saveToStorage(); updateCartUI(); renderProductTable(); renderReceiptTable(); showToast('Checkout saved locally','success'); addActivity(`Sale ${receipt.orderId} (local)`);
}

// --- PRODUCTS MANAGEMENT ---
function renderProductTable(){ const el=document.getElementById('productTable'); if(!el) return; if(medicines.length===0){ el.innerHTML='<div>No products</div>'; return; } el.innerHTML=`<table><thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Expiry</th><th>Actions</th></tr></thead><tbody>${medicines.map(m=>`<tr><td>${m.id}</td><td>${m.name}</td><td>${m.category||''}</td><td>₱${m.price.toFixed(2)}</td><td>${m.stock}</td><td>${m.expiryDate||''}</td><td><button onclick="editProduct(${m.id})">Edit</button><button onclick="archiveProduct(${m.id})">Archive</button><button onclick="deleteProduct(${m.id})">Delete</button></td></tr>`).join('')}</tbody></table>`; }
function showAddProductModal(){ const mod=document.getElementById('modals'); mod.innerHTML=`<div class="modal active" id="productModal"><div class="modal-content"><h2>Add Product</h2><div><label>Name</label><input id="p_name"></div><div><label>Price</label><input id="p_price" type="number" step="0.01"></div><div><label>Stock</label><input id="p_stock" type="number"></div><div><label>Expiry</label><input id="p_expiry" type="date"></div><div><button onclick="saveProduct()">Save</button><button onclick="closeModal('productModal')">Cancel</button></div></div></div>`; }
function closeModal(id){ const el=document.getElementById(id); if(el) el.classList.remove('active'); document.getElementById('modals').innerHTML=''; }
function editProduct(id){ const p=medicines.find(m=>m.id===id); if(!p) return; const mod=document.getElementById('modals'); mod.innerHTML=`<div class="modal active" id="productModal"><div class="modal-content"><h2>Edit Product</h2><input type="hidden" id="p_id" value="${p.id}"><div><label>Name</label><input id="p_name" value="${p.name}"></div><div><label>Price</label><input id="p_price" type="number" step="0.01" value="${p.price}"></div><div><label>Stock</label><input id="p_stock" type="number" value="${p.stock}"></div><div><label>Expiry</label><input id="p_expiry" type="date" value="${p.expiryDate||''}"></div><div><button onclick="saveProduct()">Save</button><button onclick="closeModal('productModal')">Cancel</button></div></div></div>`; }
async function saveProduct(){ const id = document.getElementById('p_id')?.value; const name=document.getElementById('p_name').value.trim(); const price=parseFloat(document.getElementById('p_price').value); const stock=parseInt(document.getElementById('p_stock').value,10); const expiry=document.getElementById('p_expiry').value||null; if(!name||isNaN(price)||isNaN(stock)){ showToast('Fill required fields','error'); return; }
    if(authToken){ try{ if(id){ await apiFetch(`/products/${id}`,{ method:'PUT', body:{ name, price, stock, expiry_date: expiry } }); showToast('Updated (server)','success'); } else { await apiFetch('/products',{ method:'POST', body:{ name, price, stock, expiry_date: expiry } }); showToast('Created (server)','success'); } await loadFromStorage(); renderProductTable(); renderProducts(); closeModal('productModal'); return; }catch(e){ console.warn('server product save failed',e.message); showToast('Server save failed, using local','warning'); }
    }
    // local
    if(id){ const p=medicines.find(m=>m.id==id); if(p){ p.name=name; p.price=price; p.stock=stock; p.expiryDate=expiry; showToast('Product updated (local)','success'); } }
    else { const nid = medicines.reduce((mx,m)=>Math.max(mx,m.id),0)+1; medicines.push({ id: nid, name, price, stock, expiryDate: expiry, status:'active' }); showToast('Product added (local)','success'); }
    saveToStorage(); renderProductTable(); renderProducts(); closeModal('productModal'); }

function archiveProduct(id){ const p=medicines.find(m=>m.id===id); if(!p) return; archives.unshift({ type:'product', id:p.id, name:p.name, date:new Date().toISOString() }); p.status='archived'; saveToStorage(); renderProductTable(); showToast('Archived','info'); }
function deleteProduct(id){ if(!confirm('Delete product?')) return; medicines=medicines.filter(m=>m.id!==id); archives.unshift({ type:'product-delete', id, date:new Date().toISOString() }); saveToStorage(); renderProductTable(); renderProducts(); showToast('Deleted','warning'); }

// --- USERS ---
function renderPendingUsers(){ const el=document.getElementById('pendingUsersSection'); if(!el) return; const pend=pendingUsers.filter(u=>u.status==='pending'); if(pend.length===0){ el.innerHTML=''; return; } el.innerHTML=`<h4>Pending</h4><table><tbody>${pend.map(u=>`<tr><td>${u.id}</td><td>${u.username}</td><td>${u.fullname}</td><td><button onclick="approveUser(${u.id})">Approve</button><button onclick="rejectUser(${u.id})">Reject</button></td></tr>`).join('')}</tbody></table>`; }
function renderUserTable(){ const el=document.getElementById('userTable'); if(!el) return; el.innerHTML=`<table><thead><tr><th>ID</th><th>Username</th><th>Full Name</th><th>Role</th><th>Actions</th></tr></thead><tbody>${users.map(u=>`<tr><td>${u.id}</td><td>${u.username}</td><td>${u.fullname}</td><td>${u.role||'User'}</td><td><button onclick="editUser(${u.id})">Edit</button><button onclick="archiveUser(${u.id})">Archive</button><button onclick="deleteUser(${u.id})">Delete</button></td></tr>`).join('')}</tbody></table>`; }
function approveUser(id){ const idx=pendingUsers.findIndex(p=>p.id===id); if(idx===-1) return; const u=pendingUsers.splice(idx,1)[0]; u.status='active'; users.push({ id:u.id, username:u.username, fullname:u.fullname, password:u.password, role:u.role, status:'active' }); saveToStorage(); renderPendingUsers(); renderUserTable(); showToast('Approved','success'); addActivity(`Approved user ${u.username}`); }
function rejectUser(id){ if(!confirm('Reject user?')) return; pendingUsers=pendingUsers.filter(p=>p.id!==id); saveToStorage(); renderPendingUsers(); showToast('Rejected','info'); }
function editUser(id){ const u=users.find(x=>x.id===id); if(!u) return; const mod=document.getElementById('modals'); mod.innerHTML=`<div class="modal active"><div class="modal-content"><h2>Edit User</h2><input type="hidden" id="u_id" value="${u.id}"><div><label>Fullname</label><input id="u_fullname" value="${u.fullname}"></div><div><label>Role</label><input id="u_role" value="${u.role||''}"></div><div><button onclick="saveUser()">Save</button><button onclick="closeModal('userModal')">Cancel</button></div></div></div>`; }
function saveUser(){ const id=document.getElementById('u_id')?.value; if(id){ const u=users.find(x=>x.id==id); if(u){ u.fullname=document.getElementById('u_fullname').value; u.role=document.getElementById('u_role').value; saveToStorage(); renderUserTable(); closeModal('userModal'); showToast('User updated','success'); } } else { const username=prompt('username'); if(!username) return; const fullname=prompt('fullname')||username; const pw=prompt('password')||'Temp@123'; const nid=users.reduce((mx,u)=>Math.max(mx,u.id),0)+1; users.push({ id:nid, username, fullname, password:pw, role:'Staff', status:'active' }); saveToStorage(); renderUserTable(); showToast('User added','success'); } }
function archiveUser(id){ const u=users.find(x=>x.id===id); if(!u) return; u.status='archived'; archives.unshift({ type:'user', id:u.id, name:u.fullname, date:new Date().toISOString() }); saveToStorage(); renderUserTable(); showToast('User archived','info'); }
function deleteUser(id){ if(!confirm('Delete user?')) return; users=users.filter(u=>u.id!==id); archives.unshift({ type:'user-delete', id, date:new Date().toISOString() }); saveToStorage(); renderUserTable(); showToast('User deleted','warning'); }

// --- RECEIPTS ---
function renderReceiptTable(){ const el=document.getElementById('receiptTable'); if(!el) return; if(receipts.length===0){ el.innerHTML='<div>No receipts</div>'; return; } el.innerHTML=`<table><thead><tr><th>Order</th><th>Date</th><th>Cashier</th><th>Total</th></tr></thead><tbody>${receipts.map(r=>`<tr><td>${r.orderId}</td><td>${new Date(r.date).toLocaleString()}</td><td>${r.cashier}</td><td>₱${(r.total||0).toFixed(2)}</td></tr>`).join('')}</tbody></table>`; }

function filterReceipts(){ renderReceiptTable(); }

// --- ARCHIVES ---
function renderArchives(){ const el=document.getElementById('archiveTable'); if(!el) return; if(archives.length===0){ el.innerHTML='<div>No archives</div>'; return; } el.innerHTML=`<table><thead><tr><th>Type</th><th>Name</th><th>Date</th></tr></thead><tbody>${archives.map(a=>`<tr><td>${a.type}</td><td>${a.name||a.id}</td><td>${new Date(a.date).toLocaleString()}</td></tr>`).join('')}</tbody></table>`; }
function clearAllArchives(){ if(!confirm('Clear all archives?')) return; archives=[]; saveToStorage(); renderArchives(); showToast('Archives cleared','info'); }

// --- HR / Leave Requests ---
function renderLeaveRequests(){ const el=document.getElementById('leaveTable'); if(!el) return; if(leaveRequests.length===0){ el.innerHTML='<div>No requests</div>'; return; } el.innerHTML=`<table><thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>From</th><th>To</th><th>Status</th></tr></thead><tbody>${leaveRequests.map(l=>`<tr><td>${l.id}</td><td>${l.username}</td><td>${l.type}</td><td>${l.startDate}</td><td>${l.endDate}</td><td>${l.status}</td></tr>`).join('')}</tbody></table>`; }
function showLeaveRequestModal(){ const mod=document.getElementById('modals'); mod.innerHTML=`<div class="modal active"><div class="modal-content"><h2>Request Leave</h2><div><label>Type</label><input id="lr_type"></div><div><label>Start</label><input id="lr_start" type="date"></div><div><label>End</label><input id="lr_end" type="date"></div><div><label>Reason</label><textarea id="lr_reason"></textarea></div><div><button onclick="submitLeaveRequest()">Submit</button><button onclick="closeModal('leaveModal')">Cancel</button></div></div></div>`; }
function submitLeaveRequest(){ const type=document.getElementById('lr_type').value; const start=document.getElementById('lr_start').value; const end=document.getElementById('lr_end').value; const reason=document.getElementById('lr_reason').value; const id=(leaveRequests.reduce((mx,l)=>Math.max(mx,l.id||0),0)||0)+1; leaveRequests.push({ id, username: currentUser.username, type, startDate:start, endDate:end, reason, status:'pending' }); saveToStorage(); closeModal('leaveModal'); renderLeaveRequests(); showToast('Leave requested','success'); }

// --- EXPORT / UTIL ---
function exportReceipts(){ if(receipts.length===0){ showToast('No receipts','info'); return; } const csv = ['Order,Date,Cashier,Total', ...receipts.map(r=>`${r.orderId},"${r.date}","${r.cashier}",${(r.total||0).toFixed(2)}`) ].join('\n'); const blob=new Blob([csv],{type:'text/csv'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='receipts.csv'; a.click(); URL.revokeObjectURL(url); }

// --- INITIALIZE ---
(async function boot(){ await loadFromStorage(); // keep login visible until user logs in
    // autofill demo credentials for convenience (only in dev)
    document.getElementById('loginUsername').value = 'admin';
    document.getElementById('loginPassword').value = 'Admin@123';
})();

// expose some functions to global scope used by inline event handlers
window.handleLogin = handleLogin; window.togglePassword = function(){ const el=document.getElementById('loginPassword'); const btn=document.getElementById('toggleBtn'); if(el.type==='password'){ el.type='text'; btn.textContent='🙈'; } else { el.type='password'; btn.textContent='👁️'; } };
window.showRegistrationModal = function(){ alert('Use server registration if available'); };
window.addToCart = addToCart; window.checkout = checkout; window.applyDiscount = function(){ const v = prompt('Discount %', '0'); if(v!==null){ const n=parseFloat(v); if(isNaN(n) || n<0||n>100) return showToast('Invalid','error'); discount=n; updateCartUI(); showToast('Discount applied','success'); } };
window.saveProduct = saveProduct; window.showAddProductModal = showAddProductModal; window.editProduct = editProduct; window.archiveProduct = archiveProduct; window.deleteProduct = deleteProduct; window.approveUser = approveUser; window.rejectUser = rejectUser; window.exportReceipts = exportReceipts; window.clearCart = clearCart; window.holdCart = function(){ const id = heldCarts.length+1; heldCarts.push({ id, items: cart.slice(), discount }); cart=[]; saveToStorage(); updateCartUI(); showToast('Cart held','info'); };

function renderPermissionCheckboxes(selectedPermissions) {
    const container = document.getElementById('permissionCheckboxes');
    if (!container) return;
    
    // Create a grid layout for permissions
    container.innerHTML = `
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px;margin-bottom:12px;">
            ${AVAILABLE_PERMISSIONS.map(p => `
                <div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:#f8fafc;border-radius:6px;">
                    <input type="checkbox" value="${p.id}" ${selectedPermissions.includes(p.id) ? 'checked' : ''} 
                           style="width:16px;height:16px;cursor:pointer;flex-shrink:0;">
                    <label style="font-weight:400;cursor:pointer;font-size:14px;color:#333;display:flex;align-items:center;gap:4px;">
                        ${p.label}
                    </label>
                </div>
            `).join('')}
        </div>
        <div style="padding:10px 12px;background:#f0f4f8;border-radius:8px;border:1px solid #e0e7ef;">
            <label style="display:flex;align-items:center;gap:10px;font-weight:600;cursor:pointer;color:var(--primary);">
                <input type="checkbox" id="allPermissionsCheckbox" ${selectedPermissions.includes('all') ? 'checked' : ''} 
                       onchange="toggleAllPermissions()" style="width:18px;height:18px;cursor:pointer;">
                🔓 All Permissions (Full Access)
            </label>
        </div>
    `;
}

