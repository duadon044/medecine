function requireRole(...allowed) {
  return function (req, res, next) {
    const user = req.user;
    if (!user) return res.status(403).json({ message: 'Forbidden' });
    if (allowed.includes(user.role)) return next();
    return res.status(403).json({ message: 'Insufficient role' });
  };
}

module.exports = { requireRole };
