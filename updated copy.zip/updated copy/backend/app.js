require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const bodyParser = require('express').json;
const { init } = require('./db');

const authRoutes = require('./routes/auth');
const prodRoutes = require('./routes/products');
const receiptRoutes = require('./routes/receipts');
const adminRoutes = require('./routes/admin');
const authMiddleware = require('./middleware/auth');
const { requireRole } = require('./middleware/rbac');
const bcrypt = require('bcrypt');
const { db } = require('./db');

const app = express();
app.use(helmet());
app.use(cors());
app.use(bodyParser());


init();

// Bootstrap initial admin if none exists and env vars provided
try {
  const count = db.prepare("SELECT COUNT(*) as c FROM users").get().c;
  if (count === 0 && process.env.ADMIN_USERNAME && process.env.ADMIN_PASSWORD) {
    const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 10);
    db.prepare('INSERT INTO users (username, fullname, password, role, status) VALUES (?,?,?,?,?)').run(process.env.ADMIN_USERNAME, process.env.ADMIN_FULLNAME || 'Administrator', hash, 'Admin', 'active');
    console.log('Created initial admin user:', process.env.ADMIN_USERNAME);
  } else if (count === 0) {
    console.log('No users found. To create an initial admin, set ADMIN_USERNAME and ADMIN_PASSWORD in .env');
  }
} catch (e) {
  console.warn('Bootstrap admin check failed:', e.message);
}

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/products', authMiddleware, prodRoutes);
app.use('/api/receipts', authMiddleware, receiptRoutes);
app.use('/api/admin', authMiddleware, requireRole('Admin'), adminRoutes);

// admin-only product management endpoints can be protected by RBAC in client calls
// but product routes assume authenticated users; attach RBAC where needed

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`MediPOS backend running on port ${PORT}`));
