const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { db } = require('../db');

const router = express.Router();

// register -> creates a pending user
router.post('/register', [
  body('username').isLength({ min: 3 }).trim(),
  body('fullname').notEmpty().trim(),
  body('password').isLength({ min: 8 }),
  body('role').isIn(['Admin','Pharmacist','Cashier','Staff'])
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { username, fullname, password, role } = req.body;
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(409).json({ message: 'Username already exists' });
  const hash = await bcrypt.hash(password, 10);
  const stmt = db.prepare('INSERT INTO users (username, fullname, password, role, status) VALUES (?,?,?,?,?)');
  const info = stmt.run(username, fullname, hash, role, 'pending');
  return res.status(201).json({ id: info.lastInsertRowid, message: 'Registration submitted (pending approval)' });
});

// login -> only active users
router.post('/login', [ body('username').notEmpty(), body('password').notEmpty() ], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { username, password } = req.body;
  const user = db.prepare('SELECT id, username, fullname, password, role, status FROM users WHERE username = ?').get(username);
  if (!user || user.status !== 'active') return res.status(401).json({ message: 'Invalid credentials or not active' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
  const payload = { id: user.id, username: user.username, fullname: user.fullname, role: user.role };
  const secret = process.env.JWT_SECRET || 'changeme';
  const token = jwt.sign(payload, secret, { expiresIn: process.env.TOKEN_EXPIRES_IN || '8h' });
  return res.json({ token, user: payload });
});

module.exports = router;
