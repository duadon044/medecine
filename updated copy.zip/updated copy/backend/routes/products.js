const express = require('express');
const { body, validationResult } = require('express-validator');
const { db } = require('../db');
const { requireRole } = require('../middleware/rbac');

const router = express.Router();

// list products
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM products WHERE status = "active"').all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

router.post('/', requireRole('Admin', 'Pharmacist'), [ body('name').notEmpty(), body('price').isFloat({ min: 0 }), body('stock').isInt({ min: 0 }) ], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { name, category, price, stock, expiry_date } = req.body;
  const stmt = db.prepare('INSERT INTO products (name, category, price, stock, expiry_date, status) VALUES (?,?,?,?,?,?)');
  const info = stmt.run(name, category || null, price, stock, expiry_date || null, 'active');
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(product);
});

router.put('/:id', requireRole('Admin', 'Pharmacist'), [ body('name').optional().notEmpty(), body('price').optional().isFloat({ min: 0 }), body('stock').optional().isInt({ min: 0 }) ], (req, res) => {
  const id = parseInt(req.params.id);
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  const updated = Object.assign({}, p, req.body);
  db.prepare('UPDATE products SET name = ?, category = ?, price = ?, stock = ?, expiry_date = ?, status = ? WHERE id = ?').run(updated.name, updated.category, updated.price, updated.stock, updated.expiry_date, updated.status || p.status, id);
  res.json(db.prepare('SELECT * FROM products WHERE id = ?').get(id));
});

router.delete('/:id', requireRole('Admin'), (req, res) => {
  const id = parseInt(req.params.id);
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
