const express = require('express');
const { body, validationResult } = require('express-validator');
const { db } = require('../db');

const router = express.Router();

// create receipt (checkout) - expects items: [{ product_id, qty }]
router.post('/', [ body('items').isArray({ min: 1 }), body('items.*.product_id').isInt({ min: 1 }), body('items.*.qty').isInt({ min: 1 }) ], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { items } = req.body;
  const user = req.user || { id: null };

  const subtotal = items.reduce((sum, it) => {
    const p = db.prepare('SELECT price FROM products WHERE id = ? AND status = "active"').get(it.product_id);
    if (!p) throw new Error('Product not found');
    return sum + p.price * it.qty;
  }, 0);

  const discount = parseFloat(req.body.discount || 0);
  const discountAmount = (subtotal * discount) / 100;
  const total = subtotal - discountAmount;

  const insertReceipt = db.prepare('INSERT INTO receipts (order_id, subtotal, discount, discount_amount, total, cashier_id) VALUES (?,?,?,?,?,?)');
  const getMaxOrder = db.prepare('SELECT MAX(order_id) as m FROM receipts').get();
  const nextOrderId = (getMaxOrder && getMaxOrder.m) ? getMaxOrder.m + 1 : 1001;

  const receiptInfo = insertReceipt.run(nextOrderId, subtotal, discount, discountAmount, total, user.id);
  const receiptId = receiptInfo.lastInsertRowid;

  const insertItem = db.prepare('INSERT INTO receipt_items (receipt_id, product_id, name, price, qty, expiry_date) VALUES (?,?,?,?,?,?)');
  const updateStock = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?');

  const txn = db.transaction(() => {
    for (const it of items) {
      const p = db.prepare('SELECT id, name, price, stock, expiry_date FROM products WHERE id = ? AND status = "active"').get(it.product_id);
      if (!p) throw new Error('Product not found');
      if (p.stock < it.qty) throw new Error('Insufficient stock for ' + p.name);
      insertItem.run(receiptId, p.id, p.name, p.price, it.qty, p.expiry_date);
      updateStock.run(it.qty, p.id);
    }
  });

  try {
    txn();
  } catch (e) {
    // rollback occurs automatically in better-sqlite3 transaction
    return res.status(400).json({ message: e.message });
  }

  const receipt = db.prepare('SELECT * FROM receipts WHERE id = ?').get(receiptId);
  res.status(201).json({ receipt });
});

router.get('/', (req, res) => {
  // optional ?date=YYYY-MM-DD
  const date = req.query.date;
  let rows;
  if (date) rows = db.prepare('SELECT * FROM receipts WHERE date(date) = date(?) ORDER BY date DESC').all(date);
  else rows = db.prepare('SELECT * FROM receipts ORDER BY date DESC').all();
  res.json(rows);
});

router.get('/:orderId', (req, res) => {
  const orderId = parseInt(req.params.orderId);
  const r = db.prepare('SELECT * FROM receipts WHERE order_id = ?').get(orderId);
  if (!r) return res.status(404).json({ message: 'Not found' });
  const items = db.prepare('SELECT * FROM receipt_items WHERE receipt_id = ?').all(r.id);
  res.json({ receipt: r, items });
});

module.exports = router;
