const express = require('express');
const { db } = require('../db');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcrypt');

const router = express.Router();

// list pending users
router.get('/users/pending', (req, res) => {
  const rows = db.prepare('SELECT id, username, fullname, role, created_at FROM users WHERE status = "pending" ORDER BY created_at DESC').all();
  res.json(rows);
});

// approve user
router.post('/users/approve/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ message: 'User not found' });
  if (u.status !== 'pending') return res.status(400).json({ message: 'User not pending' });
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run('active', id);
  res.json({ message: 'User approved' });
});

// reject user (mark rejected)
router.post('/users/reject/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ message: 'User not found' });
  if (u.status !== 'pending') return res.status(400).json({ message: 'User not pending' });
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run('rejected', id);
  res.json({ message: 'User rejected' });
});

// create admin (only callable by Admin - but when no admin exists this endpoint can be used manually)
router.post('/create-admin', [ body('username').isLength({ min: 3 }), body('fullname').notEmpty(), body('password').isLength({ min: 8 }) ], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { username, fullname, password } = req.body;
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(409).json({ message: 'Username exists' });
  const hash = await bcrypt.hash(password, 10);
  const info = db.prepare('INSERT INTO users (username, fullname, password, role, status) VALUES (?,?,?,?,?)').run(username, fullname, hash, 'Admin', 'active');
  res.status(201).json({ id: info.lastInsertRowid, message: 'Admin created' });
});

// list all users (for admin)
router.get('/users', (req, res) => {
  const rows = db.prepare('SELECT id, username, fullname, role, status, created_at FROM users ORDER BY id').all();
  res.json(rows);
});

// archive user
router.post('/users/archive/:id', (req, res) => {
  const id = parseInt(req.params.id);
  if (id === 1) return res.status(400).json({ message: 'Cannot archive admin' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ message: 'User not found' });
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run('archived', id);
  db.prepare('INSERT INTO archives (type, ref_id, name, details) VALUES (?,?,?,?)').run('user', id, u.username, `${u.fullname} - ${u.role}`);
  res.json({ message: 'User archived' });
});

// delete user
router.delete('/users/:id', (req, res) => {
  const id = parseInt(req.params.id);
  if (id === 1) return res.status(400).json({ message: 'Cannot delete admin' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ message: 'User not found' });
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ message: 'User deleted' });
});

module.exports = router;
