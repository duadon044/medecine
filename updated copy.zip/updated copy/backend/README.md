MediPOS Backend (minimal)

This is a minimal Node/Express backend using SQLite for quick local setup.

Setup

1. Install dependencies:

```bash
cd backend
npm install
```

2. Copy environment example:

```bash
cp .env.example .env
# edit .env to set JWT_SECRET
```

3. Start server:

```bash
npm start
```

Endpoints

- `POST /api/auth/register` — register (creates pending user)
- `POST /api/auth/login` — login (active users only), returns JWT
- `GET /api/products` — list products (requires Authorization header)
- `POST /api/products` — create product (requires Authorization; restrict via role in future)
- `POST /api/receipts` — create receipt/checkout (requires Authorization)

Notes

- Passwords are hashed with bcrypt.
- No default admin account is created; create an Admin user via direct DB insert or modify startup logic.
- This is a scaffold for migration; review RBAC and validation before production.
